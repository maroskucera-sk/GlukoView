<?php
declare(strict_types=1);

// Lokálny smoke-test config — NIE pre produkciu. Súbor je v .gitignore.
return [
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'glukoview_insulin',
        'user'    => 'glukoview',
        'pass'    => 'test',
        'charset' => 'utf8mb4',
    ],
    'cors' => true,
    'family_id' => null,
    'export_timezone' => 'Europe/Bratislava',
];
